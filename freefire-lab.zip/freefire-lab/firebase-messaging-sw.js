/* Service worker for Firebase Cloud Messaging (browser push). Only used after a visitor opts in. */
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyCtXyNim4pPGPkyJOW9zQmEqnlnKtbLtcw',
  authDomain: 'chat-chat-app-b3fd3.firebaseapp.com',
  projectId: 'chat-chat-app-b3fd3',
  storageBucket: 'chat-chat-app-b3fd3.firebasestorage.app',
  messagingSenderId: '284766266907',
  appId: '1:284766266907:web:9b859c4b083326f089babe'
});
// Messages that carry a "notification" payload are displayed automatically by the browser.
firebase.messaging();
