# Chatgram
## النشر على GitHub Pages
1. أنشئ مستودعًا وارفع كل الملفات في الجذر.
2. Settings ← Pages ← Branch: main ← Save.
## إعداد Firebase
1. console.firebase.google.com ← مشروع جديد ← أضف تطبيق ويب وانسخ firebaseConfig إلى CFG داخل index.html.
2. Authentication ← Sign-in method ← فعّل Email/Password ← Settings ← Authorized domains: أضف نطاق github.io.
3. Firestore Database ← أنشئ قاعدة ← Rules ← الصق firestore.rules.
4. Storage ← ابدأ ← Rules ← الصق storage.rules.
